import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.green),
        color: Colors.greenAccent,
        debugShowCheckedModeBanner: false,
        home: HomeActivity());
  }
}

class HomeActivity extends StatelessWidget {
  HomeActivity({Key? key}) : super(key: key);

  var itemList=[
    {'img':"https://m.media-amazon.com/images/I/71s1LRpaprL._AC_SL4000_.jpg",'name':"Acer", 'title':"Acer Nitro 5", 'price':"1,27,500 BDT"},
    {'img':"https://m.media-amazon.com/images/I/61QGMX0Qy6L._AC_SL1200_.jpg",'name':"Lenovo", 'title':"Lenovo IdeaPad", 'price':"49,500 BDT"},
    {'img':"https://m.media-amazon.com/images/I/71p-M3sPhhL._AC_SL1500_.jpg",'name':"Microsoft", 'title':"Microsoft™ Surface 4", 'price':"65,500 BDT"},
    {'img':"https://m.media-amazon.com/images/I/619ev9+ZaML._AC_SL1200_.jpg",'name':"Apple", 'title':"Apple MacBook Pro", 'price':"1,72,000 BDT"},
    {'img':"https://m.media-amazon.com/images/I/71kNzt5vlBL._AC_US2180_.jpg",'name':"HP", 'title':"HP Pavilion 15", 'price':"1,05,000 BDT"},
    {'img':"https://m.media-amazon.com/images/I/61dfH5h3-2L._AC_US2180_.jpg",'name':"Dell", 'title':"Dell Latitude", 'price':"1,62,000 BDT"},
  ];

  mySnackBar(message, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(message)
        ));}

  
  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );


  // alertDialogue(context) {
  //   return showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return Expanded(
  //           child: AlertDialog(
  //         title: Text("Confirmation"),
  //         content: Text('Do you really want to submit it?'),
  //         actions: [
  //           ElevatedButton(
  //               onPressed: () {
  //                 mySnackBar('Submitted successfully', context);
  //                 Navigator.of(context).pop();
  //               },
  //               style: buttonStyle1,
  //               child: Text('Yes')),
  //           ElevatedButton(
  //               onPressed: () {
  //                 mySnackBar('The form is not submitted', context);
  //                 Navigator.of(context).pop();
  //               },
  //               style: buttonStyle2,
  //               child: Text('No')),
  //         ],
  //       )
  //       );
  //     },
  //   );
  // }

  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title: Text('Simple App'),
        titleSpacing: 12,
        toolbarOpacity: 0.7,
        elevation: 4,
        actions: [
          IconButton(
              icon: Icon(Icons.search),
              onPressed: () {
                mySnackBar(
                    'The app is at initial condition, search will not work right now',
                    context);
              }),
          IconButton(
              icon: Icon(Icons.comment),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Messages()));
              }),
          IconButton(
              icon: Icon(Icons.settings),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Settings()));
              }),
        ],
      ),
      body: Scrollbar(
        thickness: 10,
        radius: Radius.circular(5),
        child: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 2,
              childAspectRatio: 0.75,
            ),
            itemCount: itemList.length,
            itemBuilder: (context, index){
              return GestureDetector(
                onLongPress: (){
                  mySnackBar(itemList[index]['name'], context);
                },
                child: Container(
                  margin: EdgeInsets.all(1),
                  width: double.infinity,
                  height: 500,
                  child: Card(
                    color: Colors.white,
                    elevation: 20,
                    child: SizedBox(
                      height: 200,
                      width: 200,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.network(itemList[index]['img']!, fit: BoxFit.contain),
                          Text(itemList[index]['title']!, style: TextStyle(fontSize: 15,),),
                          Text(itemList[index]['price']!, style: TextStyle(fontSize: 15,),),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  ElevatedButton(
                                      onPressed: () {
                                        if(index==0){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Product1(itemList[index]['title']!,itemList[index]['img']!,itemList[index]['price']!, '©2023 Mosaeb Ibn Masud, All rights reserved')),);
                                        }
                                        if(index==1){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Product2(itemList[index]['title']!,itemList[index]['img']!,itemList[index]['price']!, '©2023 Mosaeb Ibn Masud, All rights reserved')),);
                                        }
                                        if(index==2){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Product3(itemList[index]['title']!,itemList[index]['img']!,itemList[index]['price']!, '©2023 Mosaeb Ibn Masud, All rights reserved')),);
                                        }
                                        if(index==3){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Product4(itemList[index]['title']!,itemList[index]['img']!,itemList[index]['price']!, '©2023 Mosaeb Ibn Masud, All rights reserved')),);
                                        }
                                        if(index==4){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Product5(itemList[index]['title']!,itemList[index]['img']!,itemList[index]['price']!, '©2023 Mosaeb Ibn Masud, All rights reserved')),);
                                        }
                                        if(index==5){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Product6(itemList[index]['title']!,itemList[index]['img']!,itemList[index]['price']!, '©2023 Mosaeb Ibn Masud, All rights reserved')),);
                                        }
                                      },
                                      style: buttonStyle1,
                                      child: Icon(Icons.remove_red_eye)
                                  ),
                                  Text('View details'),
                                ],
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  ElevatedButton(
                                      onPressed: () {
                                        mySnackBar('Added to your wishlist', context);
                                      },
                                      style: buttonStyle2,
                                      child: Icon(Icons.favorite)
                                  ),
                                  Text('Add to wishlist'),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }
        ),
      ),


      drawer: Drawer(
        backgroundColor: Colors.green.shade100,
        child: ListView(
          children: [
            DrawerHeader(
              padding: EdgeInsets.all(0),
              child: UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: Colors.green),
                accountName:
                    Text('MOSAEB', style: TextStyle(color: Colors.white70)),
                accountEmail: Text('info@mosaeb.com', style: TextStyle(color: Colors.white60)),
                currentAccountPicture: Image.network(
                    'https://scontent.fdac15-1.fna.fbcdn.net/v/t39.30808-6/325882583_482817727354561_7829734624195048675_n.jpg?'
                        '_nc_cat=103&ccb=1-7&_nc_sid=730e14&_nc_ohc=2-ru_auYCJkAX_n2ZfW&_nc_ht=scontent.fdac15-1.fna&oh=00_AfBtHtRGhy04K81W5r2LS4SjqJmZSHAl4-ZQKphHvSRgew&oe=63D9A1CC'),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeActivity()),);
                mySnackBar('You are already on the homepage', context);
              },
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text('Profile'),
              trailing: Icon(Icons.arrow_right_alt),
              onTap: () {
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>Profile()), (route) => true);
              },
            ),
            ListTile(
              leading: Icon(Icons.group),
              title: Text('About us'),
              trailing: Icon(Icons.arrow_right_alt),
              onTap: () {
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>AboutUs()), (route) => true);
              },
            ),
            ListTile(
              leading: Icon(Icons.contact_mail),
              title: Text('Contact us'),
              trailing: Icon(Icons.arrow_right_alt),
              onTap: () {
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>ContactUs()), (route) => true);
              },
            ),
          ],
        ),
      ),
      endDrawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              padding: EdgeInsets.all(0),
              child: UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: Colors.green),
                accountName:
                    Text('RABBIL HASAN', style: TextStyle(color: Colors.white)),
                accountEmail: Text('info@rabbil.com',
                    style: TextStyle(color: Colors.white)),
                currentAccountPicture: Image.network(
                    'https://cdn.rabbil.com/photos/images/2022/11/04/rabbilVai.png'),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeActivity()),);
              },
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text('Profile'),
              trailing: Icon(Icons.arrow_right_alt),
              onTap: () {
                mySnackBar(
                    'By tapping/clicking it, you will go to your profile',
                    context);
              },
            ),
            ListTile(
              leading: Icon(Icons.group),
              title: Text('About us'),
              trailing: Icon(Icons.arrow_right_alt),
              onTap: () {
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>AboutUs()), (route) => false);
              },
            ),
            ListTile(
              leading: Icon(Icons.contact_mail),
              title: Text('Contact us'),
              trailing: Icon(Icons.arrow_right_alt),
              onTap: () {
                mySnackBar(
                    'By tapping/clicking it, you will go to the contact us page',
                    context);
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 1,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Messages'),
        ],
        onTap: (int index) {
          if (index == 0) {
            Navigator.push(context, MaterialPageRoute(builder: (context) => Profile()));
          }
          if (index == 1) {
            mySnackBar('You can view the main homepage from here', context);
          }
          if (index == 2) {
            Navigator.push(context, MaterialPageRoute(builder: (context)=>Messages()));
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        elevation: 8,
        child: Icon(Icons.radio_button_checked),
        onPressed: () {
          mySnackBar('This is a simple floating button.', context);
        },
      ),
    );
  }
}

class Product1 extends StatelessWidget {
  String title;
  String img;
  String price;
  String copyright;
  Product1(this.title, this.img, this.price, this.copyright, {super.key});

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product: $title'),
      ),
      body: ListView(
        children:[Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Card(elevation: 20,
                    child: SizedBox(height:550,width:double.infinity,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children:[
                            Image.network('$img', height: 400),
                            Text('$title',style: TextStyle(fontSize: 50)),
                            Text('Price: $price',style: TextStyle(fontSize: 20)),
                            Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                              ElevatedButton(onPressed: (){mySnackBar('Added to your cart successfully', context);}, child: Icon(Icons.add_shopping_cart), style: buttonStyle1,),
                              ElevatedButton(onPressed: (){mySnackBar('Added to your wishlist successfully', context);}, child: Icon(Icons.favorite_border), style: buttonStyle2,)],)
                          ],
                        )
                    ),
                  ),
                  Card(elevation: 20,
                    child: SizedBox(height:320,width:double.infinity,
                      child: Column(mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('Product Details',style: TextStyle(fontSize: 30))),)),
                          Text(''),
                          Text('9th Generation Intel Core i7-9750H 6-Core Processor ( Up to 4.5 GHz )'),
                          Text(''),
                          Text('15.6" Full HD Widescreen IPS LED-backlit display | 144 hertz refresh rate | NVIDIA GeForce RTX 2060 Graphics with 6 GB of dedicated GDDR6 VRAM'),
                          Text(''),
                          Text('16GB DDR4 2666MHz Memory | 256GB PCIe NVMe SSD (2 x PCIe M.2 slots -1 slot open for easy upgrades ) & 1 - Available hard drive bay'),
                          Text(''),
                          Text('LAN: 10/100/1000 Gigabit Ethernet LAN ( RJ-45 port ) | Wireless: Intel Wireless Wi-Fi 6 AX200 802.11ax'),
                          Text(''),
                          Text('Backlit keyboard | Acer CoolBoost technology with twin fans and dual exhaust ports'),
                        ],
                      ),
                    ),
                  ),
                  Card(elevation: 20,
                    child: SizedBox(height:550,width:double.infinity,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children:[
                            Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('System specifications',style: TextStyle(fontSize: 30))),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Standing screen display size: 15.6 inches (39.6 cm)',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Max Screen Resolution: 1920 x 1080 Pixels',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Processor: 9th Gen 4.5GHz Intel Core i7-9750H',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('RAM: 16 GB DDR4',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Hard Drive: 256 GB SSD',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Graphics Coprocessor: NVIDIA GeForce RTX 2060',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Item Weight: 4.84 pounds (2.18 kg)',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Wireless Type: 802.11ax',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Number of USB 2.0: Ports 1',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Number of USB 3.0: Ports 2',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Average Battery Life: 8 Hours',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Item model number: AN515-54-728C',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Operating System: Windows 10 Home',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Product Dimensions: 14.31×10.04×0.96 inches (36.3×25.5×2.4 cm)',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Hard Drive Interface: USB 3.1',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Voltage: 100240V',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Battery: Lithium Ion battery (included)',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Date First Available: 2021-03-24 11:11:25',style: TextStyle(fontSize: 15)),)),
                            Card(color: Colors.black45,child: Center(child: Text('$copyright', style: TextStyle(color: Colors.white60,),))),
                          ],
                        )
                    ),
                  )
                ],
              ),
        ],
      ),
    );
  }
}

class Product2 extends StatelessWidget {
  String title;
  String img;
  String price;
  String copyright;
  Product2(this.title, this.img, this.price, this.copyright, {super.key});

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Product: $title'),
        ),
        body: ListView(
          children:[Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children:[
                        Image.network('$img', height: 400),
                        Text('$title',style: TextStyle(fontSize: 50)),
                        Text('Price: $price',style: TextStyle(fontSize: 20)),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                          ElevatedButton(onPressed: (){mySnackBar('Added to your cart successfully', context);}, child: Icon(Icons.add_shopping_cart), style: buttonStyle1,),
                          ElevatedButton(onPressed: (){mySnackBar('Added to your wishlist successfully', context);}, child: Icon(Icons.favorite_border), style: buttonStyle2,)],
                        )
                      ],
                    )
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:320,width:double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('Product Details',style: TextStyle(fontSize: 30))),)),
                      Text(''),
                      Text('This everyday laptop is powered by an Intel Celeron N4020 processor, 4GB DDR4 RAM, and 64 GB M.2 PCIe SSD storage'),
                      Text(''),
                      Text('Enjoy videos or Browse online on a 14" HD display panel, framed by narrow bezels'),
                      Text(''),
                      Text('Dolby Audio delivers crystal-clear sound through the built-in dual stereo speakers'),
                      Text(''),
                      Text('Light and slim, this Windows 10 laptop computer (S mode) weighs just over 3 lbs and is less than 1 inch thick'),
                      Text(''),
                      Text('WiFi 802.11 ac and Bluetooth 4.1 connectivity; ports include 2 x USB 3.1 Gen 12 (Type-A ), microSD Card Reader; HDMI; Microphone / Earphone Combo'),
                    ],
                  ),
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:500,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children:[
                        Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('System specifications',style: TextStyle(fontSize: 30))),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Standing screen display size: 14 inches (35.6 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Max Screen Resolution: 1366 x 768 Pixels',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Processor: 4.5 GHz 1.1 Intel Celeron N4020',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('RAM: 4 GB DDR4',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Hard Drive: eMMC Storage',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Graphics Coprocessor: AMD Radeon R5',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Item Weight: 3.09 pounds (1.39 kg)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Number of USB 3.0: 2 Ports',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Average Battery Life: 12 Hours',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Item model number: 81VU0079US',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Operating System: Windows 10',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Product Dimensions: 12.88×9.25×0.7 inches (32.7×23.5×1.8 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Hard Drive Interface: Solid State',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Color: Ice Blue',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Battery: Lithium Polymer battery (included)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Date First Available: 2021-05-04 09:08:19',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.black45,child: Center(child: Text('$copyright', style: TextStyle(color: Colors.white60,),))),
                      ],
                    )
                ),
              )
            ],
          ),
          ],
        ),
    );
  }
}

class Product3 extends StatelessWidget {
  String title;
  String img;
  String price;
  String copyright;
  Product3(this.title, this.img, this.price, this.copyright, {super.key});

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Product: $title'),
        ),
        body: ListView(
          children:[Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children:[
                        Image.network('$img', height: 400),
                        Text('$title',style: TextStyle(fontSize: 50)),
                        Text('Price: $price',style: TextStyle(fontSize: 20)),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                          ElevatedButton(onPressed: (){mySnackBar('Added to your cart successfully', context);}, child: Icon(Icons.add_shopping_cart), style: buttonStyle1,),
                          ElevatedButton(onPressed: (){mySnackBar('Added to your wishlist successfully', context);}, child: Icon(Icons.favorite_border), style: buttonStyle2,)],
                        )
                      ],
                    )
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:380,width:double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('Product Details',style: TextStyle(fontSize: 30))),)),
                      Text(''),
                      Text('Power to do what you want with up to 70% more speed and multitasking power than before and exclusive AMD Ryzen Microsoft Surface Edition processor.'),
                      Text(''),
                      Text('Thin, light, elegant design in choice of two sizes: light, portable 13.5 ” or larger 15 ” that’s perfect for split-screen multitasking.'),
                      Text(''),
                      Text('Show your best side on video calls with sharp video and image quality, even in low light, Thanks to a front-facing 720p HD camera'),
                      Text(''),
                      Text('Enjoy theater-like sound for movies and shoes with Omnisonic Speakers backed by immersive Dolby Atmos6.'),
                      Text(''),
                      Text('Be heard loud and clear on calls with dural far-field Studio Mics that capture your voice and reduce background noise.'),
                      Text(''),
                      Text('You’re going to need Word, Excel, and PowerPoint. Don’t forget to add Microsoft 365'),
                    ],
                  ),
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:520,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children:[
                        Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('System specifications',style: TextStyle(fontSize: 30))),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Standing screen display size: 13.5 inches (34.3 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Max Screen Resolution: 2256 x 1504 Pixels',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Processor: 4.2 GHz AMD Ryzen 5',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('RAM: 8 GB LPDDR4',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Hard Drive: 256 GB SSD',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Item Weight: 4.84 pounds (2.18 kg)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Wireless Type: 802.11ax',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Number of USB 2.0: Ports 1',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Number of USB 3.0: Ports 2',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Average Battery Life: 8 Hours',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Item model number: 5PB-00027',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Operating System: Windows 11 Home',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Product Dimensions: 13.35×9.92×2.05 inches (33.9×25.2×5.2 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Optical Drive Type: TBD',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Color: Platinum',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Battery: Lithium Ion battery (included)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Date First Available: December 3, 2021',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.black45,child: Center(child: Text('$copyright', style: TextStyle(color: Colors.white60,),))),
                      ],
                    )
                ),
              )
            ],
          ),
          ],
        ),
    );
  }
}

class Product4 extends StatelessWidget {
  String title;
  String img;
  String price;
  String copyright;
  Product4(this.title, this.img, this.price, this.copyright, {super.key});

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Product: $title'),
        ),
        body: ListView(
          children:[Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children:[
                        Image.network('$img', height: 400),
                        Text('$title',style: TextStyle(fontSize: 50)),
                        Text('Price: $price',style: TextStyle(fontSize: 20)),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                          ElevatedButton(onPressed: (){mySnackBar('Added to your cart successfully', context);}, child: Icon(Icons.add_shopping_cart), style: buttonStyle1,),
                          ElevatedButton(onPressed: (){mySnackBar('Added to your wishlist successfully', context);}, child: Icon(Icons.favorite_border), style: buttonStyle2,)],
                        )
                      ],
                    )
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:660,width:double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('Product Details',style: TextStyle(fontSize: 30))),)),
                      Text(''),
                      Text('SUPERCHARGED BY M2 PRO OR M2 MAX — Take on demanding projects with the M2 Pro or M2 Max chip. M2 Pro has 12 CPU cores, 19 GPU cores, '
                          'and up to 32GB unified memory. M2 Max has 12 CPU cores, up to 38 GPU cores, and up to 96GB unified memory.'),
                      Text(''),
                      Text('UP TO 22 HOURS OF BATTERY LIFE — Go all day thanks to the power-efficient design of the M2 Pro or M2 Max chip. '
                          'And the MacBook Pro laptop delivers exceptional performance whether it’s running on battery or plugged in.'),
                      Text(''),
                      Text('FULLY COMPATIBLE — All your pro apps run lightning fast — including Adobe Creative Cloud, '
                          'Xcode, Affinity Designer, Microsoft 365, and many of your favorite iPhone and iPad apps.'),
                      Text(''),
                      Text('ADVANCED CAMERA AND AUDIO — Look sharp and sound great with a 1080p FaceTime HD camera, '
                          'a studio-quality three-mic array, and a six-speaker sound system with Spatial Audio.'),
                      Text(''),
                      Text('CONNECT WHAT YOU WANT — MacBook Pro features a MagSafe charging port, three Thunderbolt 4 ports, an SDXC card slot, an HDMI port, '
                          'and a headphone jack. And enjoy seamless wireless connectivity with Wi-Fi 6E and Bluetooth 5.3.'),
                      Text(''),
                      Text('MAGIC KEYBOARD WITH TOUCH ID — Magic Keyboard comes with a full-height function key row and Touch ID, '
                          'which gives you a fast, easy, secure way to unlock your Mac and sign in to apps and sites.'),
                      Text(''),
                      Text('WORKS WITH ALL YOUR APPLE DEVICES — You can do Amazing things when you use your Apple devices together. '
                          'Copy something on iPhone and paste it on MacBook Pro. Use your MacBook Pro to answer FaceTime calls or send texts with Messages. And that’s just the beginning.'),
                      Text(''),
                      Text('BUILT TO LAST — The all-aluminum unibody enclosure is exceptionally durable. Free software updates keep things running smoothly and securely for years to come.'),
                      Text(''),
                      Text('LEGAL DISCLAIMERS — This is a summary of the main product features. See legal disclaimers below.LEGAL DISCLAIMERS — This is a summary of the main product features. See legal disclaimers below.'),
                    ],
                  ),
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:480,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children:[
                        Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('System specifications',style: TextStyle(fontSize: 30))),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Standing screen display size: 13.6 Inches (34.5 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Max Screen Resolution: 1920 x 1080 Pixels',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Processor: Others',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('RAM: 8 GB',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Hard Drive: 1 TB',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Graphics Coprocessor: Integrated',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Item Weight: 4.84 pounds (2.18 kg)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Special Feature: Backlit Keyboard',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Average Battery Life: 8 Hours',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Item model number: AN515-54-728C',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Operating System: Mac OS',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Product Dimensions: 14.31×10.04×0.96 inches (36.3×25.5×2.4 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Hard Drive Interface: USB 3.1',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Color: Space Grey',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Date First Available: 2022-06-10 16:23:35',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.black45,child: Center(child: Text('$copyright', style: TextStyle(color: Colors.white60,),))),

                      ],
                    )
                ),
              )
            ],
          ),
          ],
        ),
    );
  }
}

class Product5 extends StatelessWidget {
  String title;
  String img;
  String price;
  String copyright;
  Product5(this.title, this.img, this.price, this.copyright, {super.key});

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Product: $title'),
        ),
        body: ListView(
          children:[Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      children:[
                        Image.network('$img', height: 400),
                        Text('$title',style: TextStyle(fontSize: 50)),
                        Text('Price: $price',style: TextStyle(fontSize: 20)),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                          ElevatedButton(onPressed: (){mySnackBar('Added to your cart successfully', context);}, child: Icon(Icons.add_shopping_cart), style: buttonStyle1,),
                          ElevatedButton(onPressed: (){mySnackBar('Added to your wishlist successfully', context);}, child: Icon(Icons.favorite_border), style: buttonStyle2,)],
                        )
                      ],
                    )
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:360,width:double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('Product Details',style: TextStyle(fontSize: 30))),)),
                      Text('【Upgraded】 RAM is upgraded to 16 GB high-bandwidth RAM to smoothly run multiple applications and browser tabs all at once; '
                          'Hard Drive is upgraded to 512 GB Solid State Drive to allow master bootup and data transfer. Original Seal is open for upgrade ONLY. '
                          'If the computer has modifications (listed above ), then the manager box is open for it to be tested and inspired and to install the upgrades to achieve the specifications as advertised.'),
                      Text(''),
                      Text('【Processor】 Intel Core i3-1125G4 ( up to 3.7 GHz with Intel Turbo Boost Technology, 8 MB L3 cache, 4 cores)'),
                      Text(''),
                      Text('【Display】 14" FHD (1920 x 1080 ), IPS, micro-edge, anti-glare, 250 nits, 45% NTSC Display'),
                      Text(''),
                      Text('【 Operating System 】 Windows 11 Home                                                                       '),
                      Text(''),
                      Text('【 Connectivity】 Realtek RTL8821CE-M 802.11a/b/g/n/ac (1x1) Wi-Fi and Bluetooth 4.2 combo'),
                    ],
                  ),
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children:[
                        Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('System specifications',style: TextStyle(fontSize: 30))),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Standing screen display size: 14 Inches (35.6 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Max Screen Resolution: 1920 x 1080 Pixels',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Processor: 3.7 GHz core i7 1065G7',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('RAM: 16 GB DDR4',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Hard Drive: 512 GB SSD',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Graphics Coprocessor: Intel UHD Graphics',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Item Weight: 3.24 pounds (1.46 kg)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Wireless Type: Bluetooth, 802.11a',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Number of USB 2.0: Ports 1',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Number of USB 3.0: Ports 2',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Average Battery Life: 10 Hours',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Item model number: AN515-54-728C',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Operating System: Windows 11',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Product Dimensions: 12.76×8.86×0.71 inches (32.4×22.5×1.8 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Hard Drive Interface: USB 3.1',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Color: Black Silver',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Battery: Battery: 3-cell, 41 Wh Li-ion',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Date First Available: 2022-03-19 09:02:02',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.black45,child: Center(child: Text('$copyright', style: TextStyle(color: Colors.white60,),))),

                      ],
                    )
                ),
              )
            ],
          ),
          ],
        ),
    );
  }
}

class Product6 extends StatelessWidget {
  String title;
  String img;
  String price;
  String copyright;
  Product6(this.title, this.img, this.price, this.copyright, {super.key});

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  final ButtonStyle buttonStyle1 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );
  final ButtonStyle buttonStyle2 = ElevatedButton.styleFrom(
    padding: EdgeInsets.all(10),
    backgroundColor: Colors.red,
    foregroundColor: Colors.white,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(5)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Product: $title'),
        ),
        body: ListView(
          children:[Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      children:[
                        Image.network('$img', height: 400),
                        Text('$title',style: TextStyle(fontSize: 50)),
                        Text('Price: $price',style: TextStyle(fontSize: 20)),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                          ElevatedButton(onPressed: (){mySnackBar('Added to your cart successfully', context);}, child: Icon(Icons.add_shopping_cart), style: buttonStyle1,),
                          ElevatedButton(onPressed: (){mySnackBar('Added to your wishlist successfully', context);}, child: Icon(Icons.favorite_border), style: buttonStyle2,)],
                        )
                      ],
                    )
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:420,width:double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('Product Details',style: TextStyle(fontSize: 30))),)),
                      Text('15.6 inch Full HD (1920x1080 ) 60Hz IPS Display; 802.11ax Wifi, Bluetooth 5.1, Ethernet LAN ( RJ-45 ), Integrated Webcam, Full Size '),
                      Text(''),
                      Text('Powerful Performance with Intel Core i5-1135G7 Quad Core? 11th Gen Intel Core i5-1135G7 2.40GHz Processor (upto 4.2 GHz, 8MB Cache, 4-Cores ); Intel Iris Xe Integrated Graphics'),
                      Text(''),
                      Text('High Speed and Multitasking? 16GB DDR4 SODIMM; 65W Power Supply, 4-Cell 54 WHr Battery; Black Color'),
                      Text(''),
                      Text('Enormous Storage? 512GB PCIe NVMe SSD; 2 USB 3.2 Gen1, 1 USB 2.0, 1 HDMI, Thunderbolt 3 (Type-C), SD Reader, No Optical Drive, Headphone/Microphone Combo Jack.'),
                      Text(''),Row(mainAxisAlignment: MainAxisAlignment.start,children: [Text('Windows 11 Pro-64')],),
                      Text(''),Row(mainAxisAlignment: MainAxisAlignment.start,children: [Text('Display Size: 15.6 inches'),],),
                      Text(''),Row(mainAxisAlignment: MainAxisAlignment.start,children: [Text('Hard Disk Size: 512.00 GB'),],),
                      Text(''),Row(mainAxisAlignment: MainAxisAlignment.start,children: [Text('System RAM Type: DDR4 SDRAM'),],),
                      Text(''),Row(mainAxisAlignment: MainAxisAlignment.start,children: [Text('RAM Memory Installed Size: 16.00 GB'),],),
                    ],
                  ),
                ),
              ),
              Card(elevation: 20,
                child: SizedBox(height:550,width:double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children:[
                        Card(color: Colors.white,child: SizedBox(width: double.infinity,child: Center(child: Text('System Specifications',style: TextStyle(fontSize: 30))),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Standing screen display size: 15.6 inches (39.6 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Max Screen Resolution: 1920 x 1080 Pixels',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Processor: 2.4 GHz core i5 Family',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('RAM: 16 GB DDR4',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Memory Speed: 3200 MHz',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Hard Drive: 256 GB SSD',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Graphics Coprocessor: Intel Iris Xe Graphics',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Item Weight: 4.84 pounds (2.18 kg)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Wireless Type: Bluetooth, 802.11ax',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Average Battery Life: 10 Hours',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Item model number: AN515-54-728C',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Operating System: Windows 11 Pro',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Product Dimensions: 14.31×10.04×0.96 inches (36.3×25.5×2.4 cm)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Hard Drive Interface: USB 3.1',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Special Feature: Anti-glare Screen',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white54,child: SizedBox(width: double.infinity,child: Text('Battery: Lithium Ion battery (included)',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.white70,child: SizedBox(width: double.infinity,child: Text('Date First Available: 2021-07-19 06:36:51',style: TextStyle(fontSize: 15)),)),
                        Card(color: Colors.black45,child: Center(child: Text('©2023 Mosaeb Ibn Masud, All rights reserved', style: TextStyle(color: Colors.white60,),))),

                      ],
                    )
                ),
              )
            ],
          ),
          ],
        ),
    );
  }
}

class Profile extends StatelessWidget {
  const Profile({Key? key}) : super(key: key);

  mySnackBar(msg, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(msg)
        ));}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Profile'),
        titleSpacing: 12,
        toolbarOpacity: 0.7,
        elevation: 4,
        actions: [
          IconButton(
              onPressed: () {

              },
              icon: Icon(Icons.search)),
          IconButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Messages()));
              },
              icon: Icon(Icons.comment)),
          IconButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Settings()));
              },
              icon: Icon(Icons.settings)),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('You can edit your profile here'),
          ],
        ),),
      bottomNavigationBar: BottomNavigationBar(
      currentIndex: 0,
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Messages'),
      ],
      onTap: (int index) {
        if (index == 0) {
          mySnackBar('You can edit your profile from here', context);
        }
        if (index == 1) {
          Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeActivity()));
        }
        if (index == 2) {
          Navigator.push(context, MaterialPageRoute(builder: (context)=>Messages()));
        }
      },
      )
    );
    }
}

class Messages extends StatelessWidget {
  Messages({Key? key}) : super(key: key);

  mySnackBar(message, context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(message)
        ));}

  var titles=[
    {'head':"You've got a new message from BAFSD",'desc':"Dear student, as you know that your teachers have to go to the training for new curriculum books came in 2023..."},
    {'head':"You've got a new message from Ostad",'desc':""},
    {'head':"You've got a new message from Shikho",'desc':""},
    {'head':"You've got a new message from 10MinuteSchool",'desc':""},
    {'head':"You've got a new message from BAFSD",'desc':""},
    {'head':"You've got a new message from Ostad",'desc':""},
    {'head':"You've got a new message from Shikho",'desc':""},
    {'head':"You've got a new message from 10MinuteSchool",'desc':""},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Your Inbox'),
          titleSpacing: 12,
          toolbarOpacity: 0.7,
          elevation: 4,
        ),

        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ListView.separated(
                itemCount: titles.length,
                itemBuilder: (context, index){
                  return Card(
                    color: Colors.green.shade50,
                    elevation: 2,
                    child: SizedBox(
                      height: 60,
                      width: double.infinity,
                      child: ListTile(
                        title: Text(titles[index]['head']!),
                        subtitle: Text(titles[index]['desc']!),
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index){
                  return Divider(
                    height: 5,
                    color: Colors.green.shade200,
                  );
                },
              )
            ],
          ),
        ),

        bottomNavigationBar: BottomNavigationBar(
          currentIndex: 2,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Messages'),
          ],
          onTap: (int index) {
            if (index == 0) {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Profile()));
            }
            if (index == 1) {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeActivity()));
            }
            if (index == 2) {
              mySnackBar('You can view the messages you received from here', context);
            }
          },
        )
    );
  }
}


class AboutUs extends StatelessWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About ourselves'),
        titleSpacing: 12,
        toolbarOpacity: 0.7,
        elevation: 4,
      ),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('How I started working with Framework?', style: TextStyle(fontSize: 20,),),

          Text('When I saw some information about flutter, I was literally mesmerized by observing how easy               `', style: TextStyle(fontSize: 12,),),
        ],
      ),
    );
  }
}

class ContactUs extends StatelessWidget {
  const ContactUs({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Our contact information'),
          titleSpacing: 12,
          toolbarOpacity: 0.7,
          elevation: 4,
        ),

        body:
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(),
            Text('Our Email Addresses', style: TextStyle(fontSize: 20,),),
            Text('info@shataj.com'),
            Text('info@softltd.com'),
            Text('info@mosaeb.com'),
            Text(''),
            Text(''),
            Text('Our Phone Numbers', style: TextStyle(fontSize: 20,),),
            Text('+8801733919791'),
            Text('+8801676680455'),
            Text('+8801616074984'),
            Text(''),
            Text(''),
            ],
        ),
    );
  }
}


class Settings extends StatelessWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Settings'),
        titleSpacing: 12,
        toolbarOpacity: 0.7,
        elevation: 4,
      ),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

        ],
      ),
    );
  }
}